package com.example.fragment

interface Comunictactor {
    fun changeData(data:String)
}